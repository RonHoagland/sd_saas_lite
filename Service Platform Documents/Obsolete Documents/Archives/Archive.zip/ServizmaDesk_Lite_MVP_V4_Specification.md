# ServizmaDesk
# ServizmaDesk Lite – MVP V4 Specification (Working Draft)

> **Document Version:** V4
> **Status:** Working Draft — In Progress
> **Last Updated:** March 2026

---

# 1. Product Identity

## Target Market
Solo and small service businesses currently managing operations with spreadsheets or no system at all:
- HVAC
- Plumbing
- Electrical
- Repair/service shops
- Primary target: 1–3 users
- Plan supports growth up to 10 users before upgrading to Plus

## Core Promise
Simple service execution with structured data that stays organized as the company grows.

## Design Principles
- Manual-first (no automation)
- Operational simplicity
- Structured long-term integrity
- Transparent data ownership
- Storage-controlled (not artificially crippled)
- Entry-level competitive positioning — lower price, focused feature set, designed to grow into Plus

---

# 2. Plan Limits (Lite)

## Pricing

Lite tier pricing is defined in **ServizmaDesk Pricing & Billing Specification V2, Section 3.1**.

For complete pricing details, see:
→ **ServizmaDesk Pricing & Billing Specification V2**

## Plan Limits

- Max Users: 10
- Attachment Storage: 3GB
- Storage Warnings:
  - 70% notice
  - 85% strong warning
  - 100% block uploads only
- CSV export allowed (Administrator role only)
- No API access
- No SMS
- No automation
- No multi-location
- No inventory automation

## Storage Upgrades Available

Storage upgrade pricing is defined in **ServizmaDesk Pricing & Billing Specification V2, Section 4**.

**Available Storage Upgrades:**
- Upgrade to 5 GB storage
- Upgrade to 10 GB storage
- Max possible storage: 10 GB

For storage pricing, see:
→ **ServizmaDesk Pricing & Billing Specification V2, Section 4**

---

# 3. Architecture & Infrastructure

ServizmaDesk Lite is built on the foundation defined in **ServizmaDesk Technical Architecture V2**.

**Key Architectural Points for Lite:**
- SDTA uses shared-schema multi-tenancy with three-layer isolation (database constraints, Django middleware, PostgreSQL RLS)
- PostgreSQL 16+ with mandatory UUIDs for all primary keys
- Django 5.x backend with HTMX v2.x frontend
- Internal REST API communication between SDP and SDTA
- Every table includes non-nullable `tenant_id` field
- Three-layer tenant isolation prevents cross-tenant data leaks

**Platform Architecture:**
- **ServizmaDesk Platform (SDP):** Back-office system handling signup, billing, and provisioning
- **ServizmaDesk Tenant App (SDTA):** Customer-facing application for Lite/Plus operations

For complete architectural details, see:
→ **ServizmaDesk Technical Architecture V2**

For complete data model specifications, see:
→ **ServizmaDesk Technical Architecture V2**
→ **ServizmaDesk SDTA Data Models V3**
→ **ServizmaDesk Platform (SDP) Specification V2**

---

# 4. Authentication & Account Creation

---

## 4.1 Overview

Authentication in SDTA is username and password based. All login, session, lockout, and password management behavior is handled within SDTA. Account signup and initial tenant provisioning is handled in SDP.

---

## 4.2 Self-Service Signup Flow (SDP)

New customers sign up through the ServizmaDesk marketing/signup site. The signup flow is fully self-service — no manual intervention by ServizmaDesk staff is required for a standard signup.

### Signup Steps (SDP)

1. Customer selects a plan (Lite)
2. Customer enters business and contact information
3. Customer enters billing information and completes payment via Stripe
4. Customer completes the Security Verification Setup (required — cannot be skipped):
   - Selects 4 security questions from a predefined list
   - Provides an answer for each question
   - Sets a 6-digit numeric Security PIN
5. SDP generates a Tenant UUID and provisions the SDTA account atomically:
   - Tenant record created in SDTA
   - First Administrator Employee record created in SDTA (using signup contact details)
   - Default Preferences record created in SDTA
   - Required system lookup data seeded for the account
6. Customer receives a welcome email with login instructions
7. Customer is redirected to the SDTA login page

> **Decision:** Security Verification Setup (questions + PIN) is a required, non-skippable step during SDP signup. These credentials are stored in SDP and are used exclusively for Administrator account recovery. They are never stored in SDTA.

---

## 4.3 Login (SDTA)

### Credentials
- Username (company email address)
- Password

### Login Behavior
- Only Employees with Status = Active may authenticate
- Successful login creates a Session record (see Section 15 — Security, Sessions, and Audit)
- Failed login attempts are recorded against the account

### Failed Login Lockout
- After **5 consecutive failed login attempts** the Employee account is locked
- A locked account cannot attempt further logins
- The login screen displays: *"Your account has been locked. Please contact your Administrator."*
- Locked accounts generate an Audit Event

> **Decision:** 5 attempts before lockout. This applies to all Employee roles including Administrator. See Section 4.6 for the Administrator lockout recovery process.

### Session Timeout
- Sessions automatically expire after a configurable idle period
- The timeout value is set by the Administrator in Preferences
- Minimum timeout: 15 minutes
- Maximum timeout: 8 hours
- Default timeout: 30 minutes
- On timeout, the user is logged out and redirected to the login page with the message: *"Your session has expired. Please log in again."*

---

## 4.4 Password Management

### Password Rules
- Minimum 8 characters
- Must include at least one uppercase letter, one lowercase letter, one number, and one special character (e.g. ! @ # $ % ^ & *)
- Passwords are never stored in plaintext
- Passwords are hashed using a secure algorithm (bcrypt or equivalent)

### Password Reset — Standard Employees (User / Read-Only)
In Lite, password resets for non-Administrator employees are performed manually by an Administrator from the Admin Area. No email is sent. (Note: Plus, Pro, and Enterprise tiers allow users to reset their own passwords via email.)

Process:
1. Administrator navigates to the Employee record in the Admin Area
2. Administrator selects Reset Password and enters a new password for the employee manually
3. Administrator securely communicates the new temporary password to the employee outside the system
4. The system enforces a "Force password change on next login" requirement

> **Note:** There is no self-service password reset link for standard employees in Lite, and no emails are sent for this process.

### Password Reset — Administrator (Self-Locked)
If an Administrator's own account is locked (see Section 4.3), they cannot access SDTA to reset it themselves. Recovery is handled through SDP using the Security Verification credentials established at signup.

See Section 4.6 for the full Administrator Recovery Process.

---

## 4.5 Unlocking a Locked Employee Account (Non-Administrator)

When a non-Administrator employee account is locked:
- The Administrator navigates to the Employee record in the Admin Area
- The Administrator selects Unlock Account
- The unlock action generates an Audit Event
- The employee may attempt to log in again immediately after unlock
- The failed attempt counter is reset to zero on unlock

---

## 4.6 Administrator Account Recovery (SDP)

This process applies only when an Administrator's SDTA account is locked and they cannot access the system to unlock it themselves.

### Recovery Process

1. Administrator contacts ServizmaDesk support (via SDP support channel)
2. ServizmaDesk support staff initiates a recovery request in SDP
3. The Administrator must pass identity verification:

**Step 1 — Security PIN**
- Administrator provides their 6-digit Security PIN set during signup
- If PIN is correct, proceed to Step 2
- If PIN is incorrect, fall back to billing verification (see below)

**Step 2 — Security Questions**
- Administrator is presented with their 4 security questions
- Administrator must answer **2 of 4 questions correctly**
- Answers are case-insensitive
- If 2 of 4 answers are correct, identity is verified

**Billing Verification Fallback**
If the Administrator cannot provide the PIN, they must instead verify:
- Business name on the account
- Billing email address
- Last 4 digits of the card on file

All three billing details must match exactly.

4. Once identity is verified by ServizmaDesk support staff in SDP, the Administrator account is unlocked in SDTA
5. The unlock action is logged in both SDP and SDTA audit records
6. The Administrator is required to reset their password on next login

### Governance Rules
- ServizmaDesk support staff cannot unlock an Administrator account without passing identity verification
- Identity verification answers and PIN are stored only in SDP — never in SDTA
- All recovery actions are logged in SDP for internal audit
- Security questions and PIN may be updated by the Administrator from within SDP account settings at any time

---

## 4.7 Security Verification Credential Management (SDP)

The Administrator may update their security credentials at any time from their SDP account settings.

### Updatable Items
- Any or all of the 4 security question selections and answers
- The 6-digit Security PIN

### Rules
- Security question updates require the current PIN to confirm
- PIN updates require correctly answering 2 of 4 current security questions to confirm
- All updates to security credentials are logged in SDP

---

## 4.8 Predefined Security Question List

The following questions are available for selection during signup and in SDP account settings. The customer selects 4 from this list. No two selections may be the same question.

- What was the name of your first pet?
- What city were you born in?
- What is your mother's maiden name?
- What was the make of your first car?
- What was the name of your elementary school?
- What is the name of the street you grew up on?
- What was your childhood nickname?
- What was the name of your first employer?
- What city did you meet your spouse or significant other?
- What is the middle name of your oldest sibling?
- What was the name of the hospital where you were born?
- What was the first concert you attended?
- What is the name of your favorite childhood friend?
- What was the model of your first computer?
- What is your oldest cousin's first name?

> **Note:** This list may be expanded in future versions. Questions are managed in SDP and are shared across all plans.

---

## 4.9 Governance Rules (Authentication)

1. All login attempts (success and failure) generate a Session or Audit record.
2. Account lockout triggers after 5 consecutive failed attempts for any Employee.
3. Locked non-Administrator accounts are unlocked only by an Administrator from the Admin Area.
4. Locked Administrator accounts are unlocked only through SDP identity verification by ServizmaDesk support staff.
5. Passwords are never stored in plaintext and are never displayed after creation.
6. Session timeout is configurable by Administrator within defined bounds (15 min – 8 hours).
7. Security verification credentials (questions, answers, PIN) are stored only in SDP and never in SDTA.
8. All recovery actions are dual-logged in both SDP and SDTA audit systems.

---

# 5. Record Numbering

---

## 5.1 Overview

Every major object in SDTA is assigned a human-readable record number at the time of creation. Record numbers are tenant-scoped — they are unique within a tenant account and are never shared or compared across tenants.

Record numbers serve two purposes: they give users a short, memorable reference for every record, and they give ServizmaDesk support staff a human-readable identifier when assisting customers.

Record numbers are system-generated and are never editable by the user.

---

## 5.2 Year Encoding

Two different year encoding methods are used depending on the object type.

### Standard Year Encoding
All objects except Products use the last two digits of the calendar year directly in the record number prefix.

**Examples:**
- 2026 → **26**
- 2027 → **27**
- 2030 → **30**

### Reverse Alphabet Year Encoding (Products Only)
Products use a two-letter reverse alphabet year prefix. Each digit of the last two digits of the year maps to a letter as follows:

| Digit | Letter |
|-------|--------|
| 0     | Z      |
| 1     | Y      |
| 2     | X      |
| 3     | W      |
| 4     | V      |
| 5     | U      |
| 6     | T      |
| 7     | S      |
| 8     | R      |
| 9     | Q      |

Each digit of the year is encoded individually. Only the last two digits of the year are used.

**Examples:**
- 2026 → 26 → X=2, T=6 → **XT**
- 2027 → 27 → X=2, S=7 → **XS**
- 2030 → 30 → W=3, Z=0 → **WZ**

---

## 5.3 Date-Sensitive Objects (Annual Reset)

Date-sensitive objects include records that are inherently tied to a point in time. For these objects the sequence number resets to 0001 at the start of each new year. The year prefix reflects the year the record was created and acts as a meaningful grouping — all W26-xxxx records were created in 2026.

**Date-Sensitive Objects and Prefixes:**

| Object      | Prefix | Example 2026 | Example 2027 |
|-------------|--------|--------------|--------------|
| Work Orders | W      | W26-0001     | W27-0001     |
| Invoices    | I      | I26-0001     | I27-0001     |
| Quotes      | Q      | Q26-0001     | Q27-0001     |
| Payments    | P      | P26-0001     | P27-0001     |

**Sequence Behavior:**
- Sequence starts at 0001 on January 1st of each year per tenant
- Sequence is zero-padded to 4 digits (0001 through 9999)
- If a tenant exceeds 9999 records in a single year the sequence expands to 5 digits (10000, 10001, etc.)
- Example across a year boundary:
  - W26-1021 (last Work Order of 2026)
  - W27-0001 (first Work Order of 2027)

---

## 5.4 Non-Date-Sensitive Objects (Continuous Sequence)

Non-date-sensitive objects are records that exist independently of time — customers, assets, and tasks accumulate over the life of the business. For these objects the sequence never resets. The year prefix reflects the year the record was first created and is informational only.

**Non-Date-Sensitive Objects and Prefixes:**

| Object        | Prefix | Example 2026 | Example 2027 |
|---------------|--------|--------------|--------------|
| Customers     | C      | C26-0001     | C27-0122     |
| Assets | A      | A26-0001     | A27-0122     |
| Tasks         | T      | T26-0001     | T27-0122     |

**Sequence Behavior:**
- Sequence starts at 0001 when the first record is created for that object type within the tenant account
- Sequence never resets — it increments continuously across years
- The year prefix updates to the current year when a new record is created, but the sequence picks up where it left off
- Example across a year boundary:
  - C26-0121 (last Customer added in 2026)
  - C27-0122 (first Customer added in 2027)

---

## 5.5 Products (Reverse Alphabet Year, Continuous Sequence)

Products use a two-letter reverse alphabet year prefix with a continuous sequence that never resets. The prefix updates each year but the sequence carries forward.

| Object   | Prefix Format  | Example (2026) | Example (2027) |
|----------|----------------|----------------|----------------|
| Products | YY (encoded)   | XT-0001        | XS-0002        |

**Sequence Behavior:**
- Sequence starts at 0001 when the first product is created in the tenant account
- Sequence never resets — it increments continuously across years
- The two-letter prefix updates to the new year encoding when a new product is created in a new year
- Example across a year boundary:
  - XT-0047 (last Product added in 2026)
  - XS-0048 (first Product added in 2027)

---

## 5.6 Sequence Generation Rules

1. Record numbers are generated by the system at the moment of record creation.
2. Record numbers are never reused, even if a record is deleted.
3. Record numbers are never editable by any user role.
4. Sequence generation is tenant-scoped — two tenants may have identical record numbers without conflict.
5. Sequence generation must be atomic — concurrent record creation cannot produce duplicate numbers within the same tenant.
6. Record numbers are stored as a field on the record and indexed for fast lookup and search.
7. Record numbers appear in all list views, detail views, audit events, and exported CSV files.
8. **User-Configurable Start Numbers**: Administrators may increase the start number for any sequence at any time (e.g., to match an legacy system's numbering after migration).
9. **Forward-Only Constraint**: The system prevents a user from choosing a start number that is less than or equal to the current system counter. This prevents accidental duplicate record numbers.
10. **Next-Number Visibility**: The Administrative interface always displays the "Next Number" to be used for each object type, derived from the current system counter.

---

## 5.7 Governance Rules

1. Every object listed in sections 5.3, 5.4, and 5.5 receives a record number at creation — no exceptions.
2. Record numbers are immutable after creation.
3. Deleted records retain their number in audit history — the number is never reassigned.
4. The sequence counter for each object type is stored per tenant and is protected against race conditions.

---

# 6. Deletion Policy

---

## 6.1 Overview

SDTA uses a **hard delete** model. When a record is deleted it is permanently removed from the database. There is no soft delete, no trash bin, and no restore capability in Lite or Plus.

Because deletion is permanent, the system enforces strict rules to prevent accidental loss of meaningful data. These rules fall into three categories: relationship blocking, status blocking, and cascade deletion of child records.

---

## 6.2 Top-Level Objects (Protected)

The following objects are top-level and are protected from deletion when blocking conditions exist:

| Object        | Blocked By                                      |
|---------------|-------------------------------------------------|
| Companies     | Any linked Assets, Quotes, Work Orders, Invoices |
| Assets | Any linked Work Orders (any status, any history)|
| Quotes        | Any linked line items                           |
| Work Orders   | Any linked line items                           |
| Invoices      | Any linked line items                           |
| Products      | Any linked Quotes, Work Orders, or Invoices (as a line item reference) |

**Tasks** are not top-level protected objects. A Task may be deleted freely regardless of its relationships or status.

---

## 6.3 Relationship Blocking Rules

A top-level record cannot be deleted if it has any related top-level records attached to it. The user must remove or reassign the blocking relationships before deletion is permitted.

**Examples:**
- A Customer with an Invoice cannot be deleted. The Invoice must be deleted first.
- An Asset with any Work Order history cannot be deleted. The Work Orders must be deleted first.
- A Work Order with line items cannot be deleted. The line items must be removed first.
- A Quote with line items cannot be deleted. The line items must be removed first.
- An Invoice with line items cannot be deleted. The line items must be removed first.
- A Product referenced as a line item on any Quote, Work Order, or Invoice cannot be deleted. The line item references must be removed first.

---

## 6.4 Status Blocking Rules

The following terminal or closed statuses block deletion entirely. A record in one of these statuses must be manually reopened before it can be deleted. Reopening a record generates an Audit Event. The subsequent deletion also generates an Audit Event.

**Statuses that block deletion:**
- Completed
- Closed
- Cancelled
- Paid
- Void
- Written Off

**Process to delete a status-blocked record:**
1. User changes the record status back to an open/active state (e.g. Draft or In Progress)
2. System generates an Audit Event for the status change
3. User resolves any remaining relationship blocks (removes line items, etc.)
4. User deletes the record
5. System generates an Audit Event for the deletion

> **Note:** Reopening a Paid, Void, or Written Off invoice for the purpose of deletion is a significant financial action and will generate both a STATUS_CHANGE and a DELETE audit event. Administrators should review audit history if discrepancies arise.

---

## 6.5 Child / Supporting Records (Cascade Delete)

The following supporting records are considered children of their parent object. When a parent record is deleted, all attached child records are permanently deleted automatically. No additional confirmation is required for child records.

**Cascade-deleted with parent:**
- Contacts
- Addresses
- Phone Numbers
- Social Info
- Notes
- Documents (attached files — storage usage is decremented accordingly)

---

## 6.6 User-Facing Error Message

When a deletion is blocked by a relationship or status condition, the system displays a clear error message identifying exactly what is preventing the delete.

**Format:**
> "This record cannot be deleted. The following must be resolved first:"
> - [List of blocking relationships or status condition]

**Examples:**
> "This record cannot be deleted. The following must be resolved first:"
> - 3 Invoices are linked to this Customer
> - 1 Work Order is linked to this Customer

> "This record cannot be deleted. The following must be resolved first:"
> - This Work Order has a status of Completed. Change the status before deleting.

> "This record cannot be deleted. The following must be resolved first:"
> - This Work Order contains 4 line items. Remove all line items before deleting.

The error message is displayed inline — no deletion occurs and no partial actions are taken.

---

## 6.7 Audit Events Generated by Deletion

The following Audit Events are generated during the delete workflow:

| Action                                      | Audit Event      |
|---------------------------------------------|------------------|
| Status changed to reopen a blocked record   | STATUS_CHANGE    |
| Top-level record deleted                    | DELETE           |

Child records deleted via cascade do not generate individual Audit Events. The parent DELETE event is sufficient.

---

## 6.8 Governance Rules

1. SDTA uses hard delete only. There is no soft delete, trash bin, or restore capability.
2. Top-level records cannot be deleted while blocking relationships exist. **Documents** are considered a blocking relationship; **Notes** are the only exception.
3. Records in terminal statuses (Completed, Closed, Cancelled, Paid, Void, Written Off) must be reopened before deletion.
4. Reopening a record for deletion generates a STATUS_CHANGE Audit Event.
5. All top-level deletions generate a DELETE Audit Event.
6. **Notes are the only record type that cascade delete with their parent.** Any other related record (Documents, Line Items, Assets) must be manually removed first to clear the blocking relationship.
7. Record numbers of deleted records are never reused.
8. Deleted records are permanently removed — there is no recovery path in Lite or Plus.
9. Any role with operational permissions (Administrator or User) may delete records subject to the rules above. Read-Only users cannot delete any records.

---

# 7. Stripe Integration

---

## 7.1 Overview

SDTA integrates with Stripe to allow tenants to accept credit and debit card payments from their customers. Stripe handles all payment processing and card data — SDTA never stores, transmits, or has access to any customer card information.

Each tenant maintains their own Stripe account. Money flows directly from the tenant's customers into the tenant's Stripe account. ServizmaDesk never handles tenant funds.

> **Decision:** Stripe Connect (Standard integration) is used to securely authenticate and link the tenant's Stripe account via OAuth. However, deep embedded payment APIs (custom card forms, split-payments) are not used in Lite. Lite uses Stripe Payment Links.

---

## 7.2 Integration Approach

Lite uses **Stripe Payment Links** exclusively. This is the simplest possible integration and requires no card data handling within SDTA.

**How it works:**
1. Tenant connects their Stripe account to SDTA (see Section 7.3)
2. When an Invoice is issued, SDTA generates a Stripe Payment Link for the invoice amount via the Stripe API
3. The Payment Link is displayed on the Invoice detail view as a copyable URL
4. The tenant shares the link with their customer via their own email or communication channel
5. The customer clicks the link, is taken to a Stripe-hosted payment page, and completes payment
6. Stripe sends a webhook notification to SDTA confirming the payment
7. SDTA automatically updates the Invoice status and records the payment (see Section 7.5)

**What SDTA never does:**
- Never displays a card entry form
- Never stores card numbers, CVV, or expiry dates
- Never transmits card data of any kind

---

## 7.3 Tenant Stripe Connection

Stripe integration is optional for tenants. Manual payment entry is always available regardless of whether Stripe is connected.

### Connection Setup
- The Administrator connects the tenant's Stripe account from the Admin Area under Preferences
- Connection is established via Stripe OAuth — the Administrator is redirected to Stripe to authorize the connection and then returned to SDTA
- SDTA stores the Stripe account ID and access token for the tenant (encrypted at rest)
- Connection status is visible in Preferences

### Stripe Button Behavior
- If Stripe is **not connected**: the Generate Payment Link button is visible on the Invoice but is grayed out and disabled. A tooltip reads: *"Connect your Stripe account in Preferences to enable payment links."*
- If Stripe is **connected**: the Generate Payment Link button is active and generates a link when clicked

### Disconnecting Stripe
- The Administrator may disconnect the Stripe account from Preferences at any time
- Disconnecting does not affect previously recorded payments
- Existing Payment Links that have already been shared become inactive. **UI Requirement:** SDTA must surface a warning modal when disconnecting ("Warning: You have X outstanding invoices with active payment links. Disconnecting will break these links for your customers.")
- The Generate Payment Link button returns to grayed out state

---

## 7.4 Payment Link Generation

- A Payment Link is generated per Invoice
- The link is tied to the Invoice amount at the time of generation
- If the Invoice amount changes after a link is generated, a new link must be generated — the old link should be considered stale
- Payment Links do not expire automatically in Lite (expiration management is the tenant's responsibility via their Stripe dashboard)
- Only one active Payment Link per Invoice is tracked in SDTA at a time — generating a new link replaces the previous link reference

---

## 7.5 Webhook Handling

Stripe notifies SDTA of payment events via webhooks. SDTA must have a registered webhook endpoint to receive these notifications.

### Events SDTA Listens For
- `payment_intent.succeeded` — payment completed successfully
- `payment_intent.payment_failed` — payment attempt failed

### On Payment Success
When SDTA receives a confirmed payment webhook from Stripe:
1. SDTA records the payment against the Invoice automatically
2. Invoice status is updated automatically:
   - If fully paid → status moves to **Paid**
   - If partially paid → status moves to **Partially Paid**
3. A PAYMENT_APPLIED Audit Event is generated with a note indicating the payment was received via Stripe
4. An in-app notification is generated for the Administrator indicating the payment was received

### On Payment Failure
When SDTA receives a failed payment webhook from Stripe:
1. No payment is recorded
2. Invoice status is unchanged
3. An in-app notification is generated for the Administrator indicating the payment attempt failed

### Webhook Security
- All incoming webhooks are verified using Stripe's webhook signature validation before processing
- Unverified or malformed webhook payloads are rejected and logged
- Duplicate webhook events (Stripe may send the same event more than once) are handled idempotently — processing the same payment event twice does not create duplicate payment records

---

## 7.6 Manual Payment Entry

Manual payment entry is always available regardless of Stripe connection status. Tenants may record cash, check, bank transfer, or any other payment method manually from within the Invoice.

Manual payments:
- Are entered by Administrator or User roles from within the Invoice record
- Require: payment date, amount, and payment method (dropdown values: Cash, Check, Bank Transfer, ACH, Other)
- Trigger the same status update logic as Stripe payments (Paid / Partially Paid)
- Generate a PAYMENT_APPLIED Audit Event

---

## 7.7 Refunds

Refunds are explicitly out of scope for Lite. If a tenant needs to issue a refund they must do so directly through their Stripe dashboard. SDTA does not initiate, track, or reconcile refunds in Lite.

> **Note:** Refund tracking is a candidate feature for Plus.

---

## 7.8 Disputes and Chargebacks

Disputes and chargebacks are handled entirely within the tenant's Stripe account. SDTA has no visibility into or involvement with dispute resolution. This is the tenant's responsibility.

---

## 7.9 Governance Rules

1. SDTA never stores, processes, or transmits card data of any kind.
2. Each tenant connects their own Stripe account — ServizmaDesk never handles tenant funds.
3. Stripe integration is optional — manual payment entry is always available.
4. All incoming webhooks are verified via Stripe signature validation before processing.
5. Webhook payment events are processed idempotently — duplicate events do not create duplicate records.
6. Payment Link generation requires Stripe to be connected and the Invoice to be in Issued status.
7. A new Payment Link must be generated if the Invoice amount changes after the original link was created.
8. All payments (Stripe and manual) generate a PAYMENT_APPLIED Audit Event.
9. Refunds and disputes are out of scope for Lite and are managed by the tenant in their Stripe dashboard.

---

# 8. Onboarding & First Run Experience

---

## 8.1 Overview

When a new tenant logs into SDTA for the first time, the system provides a brief guided experience to help them get oriented and set up. The goal is to get the tenant to their first real record as quickly as possible without overwhelming them.

The detailed onboarding content, copy, and marketing experience is defined in the ServizmaDesk Platform specification. This section defines only the SDTA-side behavior.

---

## 8.2 First Login Wizard

On the very first login by the Administrator after account provisioning, SDTA launches a short setup wizard before displaying the main application.

The wizard covers the minimum required setup steps:

1. **Welcome screen** — confirms the account is active and introduces the application briefly
2. **Tenant Profile** — prompts the Administrator to complete their company name, address, phone, and logo (pulls from SDP signup data as defaults)
3. **Preferences** — prompts review of timezone, date format, currency, and financial defaults
4. **Stripe Connection** — prompts the Administrator to connect their Stripe account (skippable — can be done later in Preferences)
5. **Completion screen** — confirms setup is done and transitions to the main dashboard

The wizard is shown only once. If the Administrator closes or skips it mid-way, it does not reappear. The Administrator can complete any skipped steps manually from the Admin Area.

> **Decision:** The wizard is shown to the first Administrator only on their first login. Subsequent logins and all other Employee logins go directly to the dashboard.

---

## 8.3 Setup Checklist (Dashboard)

After the wizard is dismissed or completed, a Setup Checklist widget appears on the dashboard. The checklist tracks the key steps needed to make the account fully operational.

**Checklist items:**

1. Complete tenant profile
2. Set preferences (timezone, currency, financial defaults)
3. Add your first Customer
4. Add your first Asset
5. Connect Stripe (optional)
6. Add additional Employees (optional)

Each item displays a checkmark when completed. The checklist widget disappears automatically from the dashboard once all non-optional items are marked complete. Optional items (Stripe, additional Employees) do not block checklist completion.

The checklist is visible to the Administrator only. Regular Users do not see it.

---

## 8.4 Governance Rules

1. The first-login wizard is shown once to the first Administrator only.
2. Closing or skipping the wizard mid-way does not relaunch it.
3. The dashboard checklist disappears automatically when all required items are complete.
4. Optional checklist items (Stripe, additional Employees) do not block completion.
5. Detailed onboarding content and SDP-side experience is defined in the SDP specification.

---

# 9. Notifications

---

## 9.1 Overview

SDTA uses a minimal, targeted notification system. The philosophy is that most operational information is surfaced through the dashboard counters and Admin Area displays. Notifications are reserved for events that need to proactively interrupt the user — things they would not find on their own quickly enough.

In Lite, notifications are delivered as dismissable banners at the top of the screen.

---

## 9.2 Notification Display

All notifications appear as a **dismissable banner at the top of the screen**, below the navigation bar.

**Banner behavior:**
- Appears immediately when the triggering event occurs or on the next page load after the event
- Remains visible until the user explicitly dismisses it
- Dismissing a banner marks it as read — it does not reappear
- Multiple banners stack vertically if more than one is active
- Banners are color-coded by type:
  - **Green** — success/confirmation (e.g. payment received)
  - **Red** — failure/action required (e.g. payment failed)

---

## 9.3 Notification Events (Lite)

The following events generate a banner notification in Lite:

### Stripe Payment Received
- **Trigger:** SDTA receives a successful payment webhook from Stripe
- **Recipient:** Administrator only
- **Color:** Green
- **Message:** *"Payment of [amount] received for Invoice [invoice number]."*
- **Dismissable:** Yes

### Stripe Payment Failed
- **Trigger:** SDTA receives a failed payment webhook from Stripe
- **Recipient:** Administrator only
- **Color:** Red
- **Message:** *"A payment attempt for Invoice [invoice number] failed. Please follow up with your customer."*
- **Dismissable:** Yes

### Employee Account Locked
- **Trigger:** Any Employee account is locked due to 5 consecutive failed login attempts
- **Recipient:** Administrator only
- **Color:** Red
- **Message:** *"Employee [display name] has been locked out after too many failed login attempts. Unlock their account from the Employee section in the Admin Area."*
- **Dismissable:** Yes

---

## 9.4 What Is Not a Notification

The following are handled by dashboard counters and Admin Area displays — they do not generate banner notifications:

- Storage usage warnings (70%, 85%, 100%) — visible in the storage meter on the dashboard and in Preferences
- Seat limit reached — visible in the Employee section of the Admin Area
- Overdue invoices — visible in the dashboard counter and Invoices report
- Work Orders scheduled today — visible in the dashboard counter and Calendar

---

## 9.5 Governance Rules

1. Notifications are delivered as dismissable banners only — no email, no SMS, no push notifications in Lite.
2. All notifications are shown to the Administrator only.
3. Dismissed notifications do not reappear.
4. Notification history is not stored or viewable after dismissal in Lite.
5. All other operational alerts are surfaced through dashboard counters and Admin Area displays.

---

# 10. Error States

---

## 10.1 Overview

SDTA uses a consistent, user-friendly error handling pattern across all forms, actions, and system events. Errors are surfaced close to where they occur, with clear language that tells the user what went wrong and what they need to do about it.

Technical error details (stack traces, server logs) are never shown to the user.

---

## 10.2 Form Validation Errors

Form validation errors occur when a user submits a form with missing required fields or invalid data.

**Display behavior:**
- A **summary banner** appears at the top of the form listing all errors that need to be resolved
- An **inline error message** appears directly below each field that has an error
- The form does not submit and the user remains on the same page
- Fields with errors are highlighted (red border or equivalent)
- Errors clear automatically as the user corrects each field

**Summary banner format:**
> *"Please correct the following before saving:"*
> - Customer Name is required
> - Phone Number is not a valid format

**Inline field format:**
> *"This field is required."*
> *"Please enter a valid email address."*

---

## 10.3 Action Errors

Action errors occur when a user attempts an operation that cannot be completed due to business rules — for example attempting to delete a record that has related data, or trying to add an employee when the seat limit is reached.

**Display behavior:**
- An **inline error message** appears at the point where the action was attempted
- The message clearly explains what went wrong and what must be done to resolve it
- No page redirect occurs — the user stays in context
- The message remains visible until the user takes corrective action or navigates away

**Examples:**
> *"This record cannot be deleted. The following must be resolved first:"*
> - 2 Invoices are linked to this Customer

> *"Maximum employee limit reached for the Lite plan. Set an existing employee to Terminated to free a seat."*

> *"This Work Order cannot be deleted. It has a status of Completed. Change the status before deleting."*

---

## 10.4 System Errors

System errors occur when something goes wrong on the server side — a failed database write, a timeout, an unexpected exception.

**Display behavior:**
- An **inline error message** appears at the point where the action was attempted
- The message is friendly and non-technical
- The message suggests the user try again or contact support if the problem persists
- The error is logged server-side for developer review
- No technical details are exposed to the user

**Standard system error message:**
> *"Something went wrong and your action could not be completed. Please try again. If the problem continues, contact support."*

---

## 10.5 Permission Errors

Permission errors occur when a user attempts to access a page or record they do not have permission to view or interact with.

**Display behavior:**
- A **modal dialog** appears explaining that access is not permitted
- The modal includes a single dismissal button (OK or Close)
- On dismissal the user is returned to the page they came from
- No technical details or role information is exposed in the message

**Modal message:**
> *"You do not have permission to access this. Please contact your Administrator if you believe this is an error."*

---

## 10.6 Page Not Found (404)

If a user navigates to a URL that does not exist within SDTA:

- A friendly **404 page** is displayed
- The page includes a button to return to the dashboard
- No technical details are shown

**Message:**
> *"We couldn't find what you were looking for. The page may have been moved or no longer exists."*

---

## 10.7 Session Expired

If a user's session times out while they are active in the application:

- The user is redirected to the login page
- A message explains why they were logged out

**Message:**
> *"Your session has expired. Please log in again."*

Any unsaved form data is lost on session expiry. This is a known limitation of Lite and is acceptable behavior.

---

## 10.8 Governance Rules

1. Technical error details are never exposed to the user under any circumstances.
2. All system errors are logged server-side for developer review.
3. Form validation errors display both a summary banner and inline field-level messages.
4. Action errors display inline at the point of the attempted action with clear resolution instructions.
5. System errors display an inline friendly message with a suggestion to retry or contact support.
6. Permission errors display a modal dialog — user is returned to their previous page on dismissal.
7. Session expiry redirects to the login page with an explanatory message.
8. Unsaved form data lost on session expiry is acceptable behavior in Lite.

---

# 11. Data Validation

---

## 11.1 Overview

SDTA enforces a consistent set of data validation rules across all forms and modules. This section defines system-wide validation standards and field type patterns. Per-field validation specifics are handled at build time for each module.

Validation fires on form submit only. There is no real-time validation as the user types.

---

## 11.2 Required vs Optional Fields

- Required and optional field designations are defined per module during the build phase
- Required fields that are left blank trigger a validation error on submit
- Optional fields accept an empty value — an empty string is valid and stored as null in the database
- The UI must clearly distinguish required fields from optional fields (e.g. asterisk marker)

---

## 11.3 Field Type Validation Rules

### Phone Numbers
- **Default format:** US format — (XXX) XXX-XXXX or XXX-XXX-XXXX
- **Localization:** If the account locale is set to a non-US region in Preferences, loose format validation is applied — minimum 7 digits, maximum 15 digits, allows spaces, dashes, dots, and a leading + for country code
- **Storage:** Stored as entered after passing validation — no normalization required in Lite
- **Invalid example:** "abc123" — rejected

### Email Addresses
- Must contain exactly one @ symbol
- Must have a valid domain portion (e.g. name@domain.com)
- Maximum 254 characters (RFC 5321 standard)
- Case-insensitive — stored as entered
- **Invalid example:** "notanemail" — rejected

### Currency / Dollar Amounts
- Must be a numeric value
- Maximum 2 decimal places
- Zero (0.00) is valid where the field allows it
- Negative values are permitted — whether a specific field allows negatives is defined in the module spec
- Currency symbol is display-only and determined by the account's currency setting in Preferences — it is not stored with the value
- **Invalid examples:** "abc", "10.999" — rejected

### Dates
- Must be a valid calendar date
- Format displayed to the user is determined by the account's date format setting in Preferences (e.g. MM/DD/YYYY or DD/MM/YYYY)
- Stored internally as ISO 8601 (YYYY-MM-DD) regardless of display format
- Future dates are permitted unless the field spec explicitly restricts them
- **Invalid example:** "02/31/2026" — rejected (February 31 does not exist)

### Percentage Fields (e.g. Tax Rate)
- Must be a number between 0 and 100 inclusive
- Maximum 3 decimal places (e.g. 8.375%)
- Zero (0) is valid
- Values above 100 are not permitted
- **Invalid examples:** "-5", "101", "abc" — all rejected

### ZIP / Postal Codes
- **Default format:** US ZIP code — 5 digits (XXXXX) or ZIP+4 (XXXXX-XXXX)
- **Localization:** If the account locale is set to a non-US region in Preferences, loose format validation is applied — alphanumeric, spaces and dashes permitted, 3–10 characters
- **Invalid example (US):** "1234" (too short), "ABCDE" (non-numeric) — rejected

### URLs (Social Links)
- Must begin with http:// or https://
- Must contain a valid domain structure
- Maximum 500 characters
- Empty is valid — social link fields are optional
- **Invalid example:** "facebook.com/mypage" (missing protocol) — rejected

---

## 11.4 Text Field Length Limits

Standard text length limits apply across all modules unless a field spec defines otherwise:

| Field Type          | Maximum Length |
|---------------------|----------------|
| Short text (names)  | 255 characters |
| Medium text (descriptions, addresses) | 500 characters |
| Long text (notes, comments) | 5000 characters |
| SKU / reference codes | 100 characters |
| Email addresses     | 254 characters |
| URLs                | 500 characters |

Fields that exceed the maximum length trigger a validation error on submit.

---

## 11.5 Uniqueness Rules

The following fields must be unique within the scope defined:

| Field                  | Unique Scope         |
|------------------------|----------------------|
| Employee company email | Per tenant account   |
| Product SKU            | Per tenant account   |
| Record numbers         | Per object type per tenant |

Uniqueness is enforced at the application level (Django) and at the database level via a compound unique constraint on `(tenant_id, field)` — ensuring two tenants may have identical values without conflict.

**Uniqueness error message format:**
> *"This [field name] is already in use. Please enter a different value."*

---

## 11.6 Cross-Field Validation Rules

Some fields must be validated in relation to each other:

- **Warranty Start / Warranty End** — End date must be equal to or later than Start date
- **Invoice Due Date** — Must be equal to or later than the Invoice date
- **Termination Date** — Must be equal to or later than Hire Date
- **Date ranges in reports** — End date must be equal to or later than Start date

Cross-field validation errors are surfaced in the summary banner at the top of the form.

---

## 11.7 Governance Rules

1. Validation fires on form submit only — no real-time validation as the user types.
2. Required and optional field designations are defined per module during the build phase.
3. Optional fields accept empty values — stored as null in the database.
4. Field type validation rules defined in Section 11.3 apply system-wide across all modules.
5. Localization settings in Preferences override US-default format rules for phone and ZIP fields.
6. Currency values are never stored with a currency symbol — symbol is display-only.
7. All dates are stored internally as ISO 8601 regardless of the display format set in Preferences.
8. Uniqueness constraints are enforced at both the application level and the database level via compound unique constraints on (tenant_id, field).
9. Cross-field validation errors appear in the form summary banner.
10. Technical validation details are never exposed to the user — all messages use plain language.

---

# 12. Core Modules Included

---

## 12.1 Dashboard (Operational Overview)

Not analytics-heavy.

Displays:
- Work Orders Today
- Open Work Orders
- Open Invoices
- Overdue Invoices
- Revenue This Month
- Storage Usage Meter

No charts required.

---

## 12.2 Companies

### Capabilities
- Create / Edit / Delete
- Status lifecycle enforced
- Embedded Sections - Limited record count
  - Contacts (2)
  - Addresses (Billing — required, Shipping — optional)
  - Phone Numbers (Fax, Phone1, Phone2)
  - Social Info (Type, Name, URL — flexible, multiple entries)
- Linked to:
  - Assets
  - Quotes
  - Work Orders
  - Invoices
  - Notes
  - Documents
  - Tasks

### Features
- Search
- Filters
- List view
- CSV export

---

## 12.3 People

### Types
- Contacts (linked to Customer)
- Employees (system users)

### Capabilities
- Create/Edit contacts
- Assign Work Orders
- Role-based access

---

## 12.4 Products & Services (Catalog Only)

Lite is catalog-only.

### Fields
- Name
- Type (Part, Service, Consumable, Kit)
- SKU
- Unit Price
- Unit Cost (optional)
- Manual Quantity (informational only)
- Active/Inactive

### Not Included
- Auto-decrement
- Inventory movement
- Adjustments
- Transfers
- Locations
- Purchase Orders

---

## 12.5 Assets (Customer Assets)

Core differentiator.

### Required Fields
- Customer (required)
- Asset Name
- Make/Model
- Serial Number
- Install Date
- Warranty Start/End
- Status (Active / Retired / Decommissioned)

### Capabilities
- View service history (Quotes, Work Orders, Invoices)
- Attach documents
- Add typed notes
- CSV export

No maintenance automation.

---

## 12.6 Quotes

Required for competitive parity.

### Relationships
- Customer (required)
- Asset (optional but encouraged)
- Line items
- Assigned user (optional)

### Status Flow
Draft → Sent → Accepted → Rejected → Expired → Converted

### Capabilities
- Create/Edit
- Convert to Work Order
- Convert to Invoice
- Attach documents
- Typed notes
- CSV export
- Browser print (user initiates from browser with CSS Print Styles)

### Not Included
- Email sending (user shares quotes via their own email)
- System PDF generation (Note for developers: Lite relies on robust **CSS Print Media** to generate perfect 8.5x11 pages via the browser. When server-side PDF generation is introduced for higher tiers, **WeasyPrint** is the designated Python integration.)
- E-signature
- Approval workflows
- Version history
- Automation reminders
- Advanced analytics

---

## 12.7 Work Orders

Primary operational object.

### Required Relationships
- Customer (required)
- Asset (required)
- Assigned User
- Line items

### Status Flow
Draft → Scheduled → In Progress → On Hold → Completed → Closed / Cancelled

### Capabilities
- Create/Edit
- Schedule date/time (set inside Work Order)
- Calendar reflects scheduled items
- Add parts/labor
- Convert to Invoice
- Attach documents
- Typed notes
- CSV export

---

## 12.8 Scheduling (Date-Sorted List View)

- Schedule is a list view sorted by the scheduled date on the Work Order. (Note: This is strictly a sortable list view, not a calendar UI).
- To reschedule a Work Order, the user edits the date directly on the Work Order record
- Filter by assigned user

No drag-and-drop.
No dispatch board.
No routing.
No optimization.

---

## 12.9 Invoices

### Relationships
- Customer (required)
- Asset (optional if standalone)
- Line items
- Payments (embedded)

### Status Flow
Draft → Issued → Partially Paid → Paid → Overdue → Void → Written Off

### Capabilities
- Create from Work Order
- Standalone invoice
- Browser print (user initiates from browser with CSS Print Styles)
- Stripe payment link (user copies and shares manually)
- CSV export

### Not Included
- Email sending (user shares invoices via their own email)
- System PDF generation (Note for developers: Lite relies on **CSS Print Media** for clean browser printing. Future automated PDF features will use **WeasyPrint**.)

---

## 12.10 Payments (Embedded in Invoice)

### Capabilities
- Manual entry
- Stripe processing
- Partial payments
- Status auto-update
- Payment history per invoice

No standalone payment module required.

---

## 12.11 Notes (Typed)

No separate Interactions object.

### Note Types
- Internal Note
- Call
- Email
- Site Visit
- Customer Comment
- Reminder

Unlimited notes.
Text does not count toward storage.

---

## 12.12 Documents (Attachments)

- Max 10 attachments per record
- Counts toward 3GB storage
- Attach to:
  - Customer
  - Asset
  - Quote
  - Work Order
  - Invoice

Uploads blocked at 100% storage.

---

## 12.13 Tasks (Basic)

- Create/Edit
- Assign to user
- Link to Customer / Asset / Quote / Work Order
- Status tracking
- CSV export

No time tracking required.

---

## 12.14 Reporting (List-Based Only)

List views + filters + search.

### Customers
- Active
- Inactive
- With Open Work Orders
- With Outstanding Balance

### Assets
- By Customer
- By Status

### Quotes
- Open Quotes
- Quotes by Customer
- Expired Quotes

### Work Orders
- Open
- By Status
- By User
- Completed (date range)

### Invoices
- Open
- Overdue
- By Customer
- By Date Range

### Payments
- By Date Range
- By Invoice

CSV export only.

---

# 13. Data Ownership & Export Policy

All Paid Tiers:
- Unlimited CSV export per table
- No restore capability

Lite:
- CSV export only

Structured Account Export reserved for Plus/Pro.

---

# 14. Storage Policy

- 3GB included
- Meter visible in Settings
- Uploads blocked at 100% capacity
- Storage upgrades available (up to 10 GB total)
- Text records not counted

---

# 15. Security, Sessions, and Audit (Lite)

This section defines the minimum security traceability needed to answer:
- Who logged in?
- Who created/deleted a record?
- Who changed a status?
- Who performed a financial-impact action?

Lite is **event-level** logging. It does **not** do field-by-field history tracking.

---

## 15.1 User Sessions (Lite)

### Purpose
A **Session** represents an authenticated user context (the "actor") for a period of activity. Audit events reference a Session.

### When a Session is created
A Session record is created on **LOGIN_SUCCESS**.

### Fields Captured
- `session_uuid` (primary identifier)
- `user_uuid`
- `username_snapshot` (optional, but helpful)
- `role_snapshot` (optional; role at login)
- `login_timestamp` (server local time)
- `logout_timestamp` (nullable)
- `end_reason` (timeout / logout / admin revoke — optional in Lite)
- `ip_address` (**required**)
- `user_agent` (recommended)
- `auth_result` (`SUCCESS` / `FAIL`)
- `fail_reason` (nullable; recommended for FAIL)

### LOGIN_FAIL Events
Lite records LOGIN_FAIL events with:
- timestamp
- username attempted (or user reference if known)
- ip_address (required)
- user_agent (recommended)
- reason if available (optional)

### Retention
Sessions are retained on a **rotating 18-month** basis. Older sessions are purged automatically.

---

## 15.2 Audit Events (Lite)

### Purpose
An **Audit Event** records meaningful actions performed by a user during a Session. Audit Events must be small, queryable, and human-reviewable.

### Core Fields
- `audit_event_uuid`
- `session_uuid` (required; ties action to session)
- `user_uuid_snapshot` (recommended)
- `timestamp` (server local time)
- `event_type` (see taxonomy below)
- `object_type` (e.g., Customer, Asset, WorkOrder, Invoice, Product)
- `record_uuid` (target record)
- `human_number` (if the object has one, e.g., I26-0001, W26-0001)
- `summary` (short human-readable description)

### Event Taxonomy (Lite)
Lite records the following event types only:

**Authentication:**
- `LOGIN_SUCCESS`
- `LOGIN_FAIL`
- `LOGOUT` (optional)

**Data Lifecycle:**
- `CREATE`
- `DELETE`

**Workflow:**
- `STATUS_CHANGE`

**Financial-Impact (required in Lite):**
- `INVOICE_ISSUED`
- `INVOICE_VOIDED`
- `INVOICE_WRITEOFF`
- `PAYMENT_APPLIED`

> Lite does not record generic UPDATE events. Field-by-field change history is not included in Lite.

### What Generates an Audit Event

**Create** — any top-tier object creation:
- Customer, Asset, Quote, Work Order, Invoice, Product, Task

**Delete** — any deletion of top-tier objects

**Status Change** — any manual status change on objects with defined lifecycles:
- Work Orders, Invoices, Quotes, Assets

**Financial-Impact Actions:**
- Issue, Void, or Write-Off an invoice
- Apply a payment to an invoice

### Retention
Audit Events are retained on a **rotating 18-month** basis. Older events are purged automatically.

---

## 15.3 Lite vs Plus/Pro Notes

- Lite: event-level only, no field diffs, no before/after values
- Plus/Pro: may introduce reason-required actions and compact before/after JSON for a targeted list of objects (to be defined in Plus specification)

---

# 16. Preferences (Lite – Account-Level Configuration)

## 16.1 Purpose

The Preferences record stores global configuration settings for the account.

- One Preferences record exists per account.
- Preferences apply to all users.
- Preferences are editable only by users with the Administrator role.
- Preferences are not tied to individual users.

---

## 16.2 Governance Rules

1. Exactly one Preferences record exists per account.
2. Only Administrator users may edit Preferences.
3. Preference updates generate an Audit Event.
4. Preferences cannot be deleted.
5. System-enforced values (e.g., storage limits, max users) are read-only in SDTA and sourced from SDP.

---

## 16.3 Tenant Profile Fields

- Tenant Legal Name
- Display Name
- Address
- Phone
- Email
- Invoice Footer Text
- Logo

---

## 16.4 Localization Fields

- Time Zone
- Date Format
- Time Format
- Currency Code
- Currency Symbol

---

## 16.5 Financial Defaults

- Default Tax Rate
- Default Payment Terms (days)
- Default Quote Expiration Days
- Default Work Order Status
- Default Invoice Status

---

## 16.6 Operational Controls

- Allow Standalone Invoice (boolean)
- Allow Standalone Quote (boolean)

---

## 16.7 Plan & Storage Controls (Read-Only)

These values are system-controlled and sourced from SDP. They are not editable by Administrator:

- Plan Storage Limit (3 GB included, up to 10 GB with upgrades)
- Current Storage Used
- Max Attachments Per Record (10)
- Max Users (10)

---

# 17. Employee Roles (Lite)

## 17.1 Purpose

Employee Roles define access levels within the Lite system.

Lite includes exactly three system-defined roles:

- Administrator
- User
- Read-Only

Roles are fixed in Lite:
- No new roles may be created
- No roles may be edited
- No roles may be deleted

---

## 17.2 Admin Area (Lite)

The Admin Area exists for system configuration and accountability tools.

Only the **Administrator** role may access the Admin Area.

Admin Area includes:
- Employees
- Roles (view-only in Lite)
- Preferences
- Audit / Sessions
- Export Tools

---

## 17.3 Role Definitions

### Administrator

Administrators can:
- Perform all operational actions (same as User)
- Access the Admin Area
- Create / Edit / Delete records (where allowed)
- Change status values
- Issue invoices, void invoices, write off invoices
- Apply and manage payments (from within invoices)
- Export data using Export Tools (Admin Area)
- Review accountability using Audit / Sessions (Admin Area)

---

### User

Users can:
- Perform all operational actions

Users cannot:
- Access the Admin Area (Employees, Roles, Preferences, Audit/Sessions, Export Tools)

Operational actions include:
- Create / Edit / Delete records (where allowed)
- Change status values
- Issue invoices, void invoices, write off invoices
- Apply and manage payments (from within invoices)

---

### Read-Only

Read-Only users can:
- Search records
- View records and list views
- View reports (list views)

Read-Only users cannot:
- Create
- Edit
- Delete
- Change status
- Issue/void/write-off invoices
- Apply payments
- Export data

---

## 17.4 Governance Rules (Lite)

1. Roles are system-defined and immutable in Lite.
2. Every Employee must be assigned exactly one role.
3. Role assignments and changes generate an Audit Event.
4. Accountability questions (e.g., "Who voided this invoice?") are answered via Audit/Sessions in the Admin Area.

Permission enforcement is required at the view/API level.

---

# 18. Employees (Lite)

## 18.1 Purpose

Employees represent internal system users.

Employees:
- Are system actors
- Are assigned exactly one Role
- Are referenced by Work Orders, Quotes, Tasks
- Are referenced in Sessions and Audit Events
- Are managed only within the Admin Area

Employees are not customers and are not part of HR management.

---

## 18.2 Admin-Only Access

- Employees are managed behind the Admin Area.
- Only Administrators may:
  - Create Employees
  - Edit Employees
  - Change Role
  - Change Status
- Employees cannot edit their own profile in Lite.

---

## 18.3 Core Fields (Lite)

### Identity
- `employee_uuid` (system identifier)
- `employee_number` (optional human-facing identifier)
- First Name
- Last Name
- `display_name` (calculated: First Name + " " + Last Name)

### Contact Information
- Address, City, State, Zip
- Phone 1
- Phone 2 (optional)
- Work Email (unique; used for login)
- Personal Email (optional)

### Employment Data (Lite Scope)
- Hire Date
- Termination Date (nullable)
- Notes (internal; Admin-only)

### Access Control
- Role (Administrator | User | Read-Only)
- Status (Active | On Leave | Inactive | Terminated)

### Audit Metadata
- Created At
- Updated At
- Created By
- Updated By

Passwords are managed by the authentication system and are never stored in plaintext.

---

## 18.4 Employee Lifecycle (Lite)

### Status Values

**Active:**
- Can log in
- Can be assigned to records

**On Leave:**
- Cannot log in
- Not assignable to new records
- Historical assignments remain

**Inactive:**
- Cannot log in
- Not assignable
- Historical assignments remain

**Terminated:**
- Cannot log in
- Not assignable
- Record preserved for audit integrity

Employee records are never deleted in Lite.

---

## 18.5 Role Assignment Rules (Lite)

1. Every Employee must have exactly one Role.
2. Roles are fixed and immutable in Lite.
3. Only Administrators may change Role or Status.
4. Role and Status changes generate Audit Events.

---

## 18.6 Login & Session Enforcement (Lite)

- Only Employees with Status = Active may authenticate.
- Successful login creates a Session record.
- Audit Events reference the Session ID.
- Changing Status to Inactive or Terminated invalidates active sessions and blocks future login.

---

## 18.7 Operational Linkages (Lite)

Employees may be referenced in:
- Work Orders (Assigned User)
- Quotes (Assigned User)
- Tasks (Assigned User)
- Audit Events (actor reference)
- Sessions (login tracking)

If an Employee becomes Inactive or Terminated:
- Existing record references remain unchanged.
- Historical integrity is preserved.

---

## 18.8 Employee Seat Limit Enforcement (Lite)

Lite includes a maximum of 10 Employees per account.

### Seat Counting Rules

The following Employee Status values **count** toward the 10-user limit:
- Active
- On Leave
- Inactive

The following status does **not** count toward the limit:
- Terminated

An Employee must be set to Terminated in order to free a seat:
- Status must be set to Terminated
- Termination Date must be populated

A Terminated Employee may be reactivated:
- This will fail if no seats are available (account is at the 10 seat maximum)
- If seats are available, reactivation proceeds and SDP is notified to bill for the additional seat

### Admin Seat Counter Display

The Employee section of the Admin Area displays:
- Seats used (x of 10)
- Monthly Seat Cost at current seat rate
- Individual Seat Cost (if under 10 seats used)
- "Maximum Seats Reached" (when all 10 seats are filled)

The cost of adding a new employee seat is displayed near the Add button. Once 10 seats are reached this changes to "Maximum Seats Reached."

When adding a new Employee, the Administrator receives a cost increase warning before confirming.

### Enforcement Behavior

If the account has 10 Employees with Status of Active, On Leave, or Inactive, the system blocks creation of additional Employees and displays:

> "Maximum employee limit reached for Lite plan."

When adding a new Employee below the 10 seat limit:
- SDTA notifies SDP of the new seat
- SDP calculates the prorated charge and bills the account accordingly
- The Administrator receives a cost increase warning before confirming the new Employee

Changing an Employee to Terminated:
- Frees one seat immediately
- SDP is notified to adjust billing accordingly
- Does not affect historical record references
- Preserves audit integrity

### Governance

1. Employee records are never deleted.
2. Status = Terminated and a populated Termination Date are required to release a seat.
3. Reactivating a Terminated Employee requires an available seat under the plan limit.

---

# 19. Explicitly Out of Scope (Lite)

- Automation
- Recurring schedules
- Inventory movement
- Purchase Orders
- Receiving
- Multi-location
- API access
- SMS
- Advanced dashboards
- Document version control
- Compliance enforcement
- Cold archive
- Full structured export
- Restore capability
- E-signature
- Server-side PDF generation (Lite requires developers to build robust **CSS Print Styles** so users can print perfectly formatted documents via the browser. When actual PDF generation is added in Plus/Pro, the codebase must use **WeasyPrint**).
- System email sending (users send from their own email accounts)
- Transactional email provider integration
- ServizmaDesk Platform specification (separate document — required dependency)

---

# 20. MVP Completion Criteria

Lite is complete when:

1. End-to-end workflow functions:
   Customer → Asset → Quote → Work Order → Invoice → Payment

2. Tenant isolation is enforced at all three layers (field constraint, middleware, RLS).

3. Storage cap operates correctly.

4. CSV export works from all major list views.

5. Roles enforce access properly.

6. No raw DB backup/restore exists in SaaS.

7. System is demo-ready without manual data intervention.

8. ServizmaDesk Platform can provision a new tenant and initialize a SDTA account atomically.

---

**End of Lite V4 Specification**